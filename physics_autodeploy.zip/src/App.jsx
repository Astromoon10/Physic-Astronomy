export default function App(){
  return <h1 style={{padding:40}}>Physics & Astronomy — Auto Deploy Ready</h1>;
}
